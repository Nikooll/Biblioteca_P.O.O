interface Prestable {
    void prestarMaterial();
    void devolverMaterial();
}