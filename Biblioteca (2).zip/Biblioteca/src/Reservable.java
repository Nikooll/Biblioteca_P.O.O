public interface Reservable {
    void reservar();
    void cancelarReserva();
}
