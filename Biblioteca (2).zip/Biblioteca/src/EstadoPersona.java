public interface EstadoPersona {
    boolean habilitado = true;
    boolean multado = false;
}