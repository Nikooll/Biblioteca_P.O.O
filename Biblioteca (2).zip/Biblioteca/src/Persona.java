class Persona {
    int idUsuario;
    String apellido;
    String nombre;
    String direccion;
    String celular;
    String correoElectronico;

    public Persona(int idUsuario, String apellido, String nombre, String direccion, String celular, String correoElectronico) {
        this.idUsuario = idUsuario;
        this.apellido = apellido;
        this.nombre = nombre;
        this.direccion = direccion;
        this.celular = celular;
        this.correoElectronico = correoElectronico;
    }
}