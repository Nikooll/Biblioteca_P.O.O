class Revista extends MaterialBibliografico {
    int volumen;
    String seccion;

    public Revista(String titulo, String autor) {
        super(titulo, autor);
    }
}